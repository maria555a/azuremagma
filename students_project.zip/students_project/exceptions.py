class GroupLimitation(Exception):
    pass
